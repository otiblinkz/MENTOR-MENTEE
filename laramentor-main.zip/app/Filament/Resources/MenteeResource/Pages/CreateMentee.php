<?php

namespace App\Filament\Resources\MenteeResource\Pages;

use App\Filament\Resources\MenteeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMentee extends CreateRecord
{
    protected static string $resource = MenteeResource::class;
}
